Component({
  options:{
    styleIsolation:'shared'
  },
  properties:{
    nodes:{
      type:Object,
      value:{}
    }
  },
  data:{
    someData:{
      
    }
  }
})